import java.util.*;
class Main {
  /*
    algorithm add
      Input: two lists of integers lst1 and lst2
      Output: a list of integers output, where the numbers respected to lst1, 
      added to the numbers respected to lst2, give us a value, that value is 
      represented as the list, output.
      
      output = empty arraylist of integers
      length = max(lst1 size, lst2 size)
      i = lst1.size - 1
      j = lst2.size - 1
      carry = 0
      sum = 0
      
      while length > 0 
        if i>-1 and j>-1
          sum = lst1.get(i) + lst2.get(j)
        else if i < 0
          sum = lst2.get(j)
        else
          sum = lst1.get(i)
       
       if carry equals 1
          if sum+carry >= 10
            sum = sum+carry - 10
            output[0]] = sum
            carry = 1
          else
            output[0] = sum+carry
            carry = 0
        else if sum >= 10
            sum = sum - 10
            output[0] = sum
            carry = 1
        else 
            output[0] = sum
        
        if i > -1 and j > -1
            decrement j
            decrement i
        else if j > -1
            decrement j
        else
            decrement i
            
        decrement length

        if carry = 1
            output[0] = carry

        return output
  */
  public static List<Integer> add(List<Integer> lst1, List<Integer> lst2) {
        ArrayList<Integer> output = new ArrayList<Integer>();

        int length = Math.max(lst1.size(),lst2.size());

        int i = lst1.size()-1;
        int j = lst2.size()-1;
        int carry = 0;
        int sum = 0;
        while (length > 0) {
            if (i >-1 && j>-1) {
                sum = lst1.get(i) + lst2.get(j);
            }
            else if (i < 0) {
                sum  = lst2.get(j);
            }
            else  {
                sum =lst1.get(i);
            }
            if(carry == 1) {
                if(sum + carry >= 10){
                    sum = (sum+carry) - 10;
                    output.add(0, sum);
                    carry = 1;
                }
                else {
                    output.add(0, sum+carry);
                    carry = 0;
                }
            }
            else if(sum >= 10) {
                sum = sum - 10;
                output.add(0, sum);
                carry = 1;
            }
            else {
                output.add(0, sum);
            }

            if(i > -1&& j > -1 ) {
                j--;
                i--;
            }
            else if ( j > -1) {
                j--;
            }
            else {
                i--;
            }
              
              length--;
        }

        if(carry == 1) {
            output.add(0, carry);
        }

        return output;
    }
  
  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * We have provided an example to help you get started.
  * 
  * use a while loop, consider the pointers(for example, when the smaller array runs out of elements,
  * what should the pointer of the bigger array be? what about the smaller array?)
  * make sure carry get's reassigned based on the previous carry!
  * also if you have a case where there is still, one more carry (no elements though), add that carry on as the first value
  * 
  * 989  + 989 = 1978
  [9, 8, 9], [9, 8, 9] => [1, 9, 7, 8]
  
  123  + 1937 = 2060
  [1, 2, 3], [1, 9, 3, 7] => [2, 0, 6, 0]
  
  1 + 9 = 10
  [1], [9] => [1, 0]
  */
  
  public static void main(String[] args) {
    List<Integer> sum = add(Arrays.asList(1, 2, 3), Arrays.asList(2, 4, 2));
    System.out.println(sum);
  }
}