import java.util.*;

public class HW7 {

  public static void main(String[] args) {
    // Q1
    System.out.println(bestValue(7, new int[] {}, new int[] {})); // 0
    System.out.println(bestValue(7, new int[] {4}, new int[] {1})); // 4
    System.out.println(bestValue(7, new int[] {4, 10, 2, 4}, new int[] {3, 1, 5, 2})); // 24
    System.out.println(bestValue(7, new int[] {4, 10, 2, 4}, new int[] {3, 3, 5, 2})); // 25
    System.out.println(bestValue(7, new int[] {4, 10, 2, 4}, new int[] {3, 5, 5, 2})); // 35

    // Q2
    System.out.println(bestValueForFused(4, new int[] {}, new int[] {})); // 0
    System.out.println(bestValueForFused(4, new int[] {4}, new int[] {1})); // 4
    System.out.println(bestValueForFused(4, new int[] {4, 10, 2}, new int[] {3, 1, 5})); // 12
    System.out.println(bestValueForFused(4, new int[] {4, 2, 2}, new int[] {3, 2, 5})); // 14
    System.out.println(bestValueForFused(6, new int[] {4, 2, 1}, new int[] {3, 3, 5})); // 18
    System.out.println(bestValueForFused(6, new int[] {4, 2, 1}, new int[] {3, 2, 9})); // 21 (3*4+9*1)

    // Q3 (Optional)
    System.out.println(Arrays.toString(bestPicksForFused(4, new int[] {}, new int[] {}))); // []
    System.out.println(Arrays.toString(bestPicksForFused(4, new int[] {4}, new int[] {1}))); // [true]
    System.out.println(Arrays.toString(bestPicksForFused(4, new int[] {4, 10, 2}, new int[] {3, 1, 5}))); // [true, false, false]
    System.out.println(Arrays.toString(bestPicksForFused(6, new int[] {4, 2, 2}, new int[] {3, 2, 5}))); // [false, true, true]
    System.out.println(Arrays.toString(bestPicksForFused(6, new int[] {4, 2, 1}, new int[] {3, 3, 5}))); // [true, true, false]
    System.out.println(Arrays.toString(bestPicksForFused(6, new int[] {4, 2, 1}, new int[] {3, 2, 9}))); // [true, false, true]
  }

  public static int bestValue(int W, int[] counts, int values[]) {
    MetalBar[] bars = new MetalBar[counts.length];

    for(int i = 0; i<values.length; i++){
        bars[i] = new MetalBar(values[i],counts[i]);
    }
    Arrays.sort(bars);

    int totalSoFar = 0;

    int i = 0;
    while(W >= 0 && i<values.length){
      int count = bars[i].getCount();
      int value = bars[i].getValue();
      
      if(W-count < 0){
          count = W;
          totalSoFar = totalSoFar + count*value;
      }

      else{
        totalSoFar = totalSoFar + count*value;
      }
      
      W -= count;
      i++;
    }

    return totalSoFar;
  }

  public static int bestValueForFused(int W, int[] counts, int values[]) {
    MetalBar[] bars = new MetalBar[counts.length];

    for(int i = 0; i<values.length; i++){
        bars[i] = new MetalBar(values[i]*counts[i],counts[i]);
    }
    Arrays.sort(bars);

    int another = 0;
    for(int i=0; i<bars.length; i++){
        int holder = i;
        int totalSoFar = 0;
        int W2 = W;

        while(W2 != 0 && holder < bars.length){
            if(W2 >= bars[holder].getCount()){
              totalSoFar += bars[holder].getValue();
              W2 -= bars[holder].getCount();
            }
            holder++;
        }

        if(totalSoFar > another){
          another = totalSoFar;
        }
    }
    
    return another;
  } 

  public static boolean[] bestPicksForFused(int W, int[] counts, int values[]) {
    return null;
  }
}

