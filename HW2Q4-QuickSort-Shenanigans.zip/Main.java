import java.util.*;

class Main {
  
  public static List<Integer> input() {
    return Arrays.asList(8, 9, 6, 7, 3, 4, 1, 2, 5, 19, 20, 17, 18, 13, 14, 16, 11, 12, 15, 10);
  }
  
  /*this problem is all about picking pivots.*/
  
  public static void main(String[] args) { }
}