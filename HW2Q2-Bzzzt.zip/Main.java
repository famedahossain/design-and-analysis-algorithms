class Main {
  /*
    The worst case would be O(1). As n (the value inputed) grows, 
    regardless of what it is, once n or n-1 is divisible by 7, meaning
    it has a remainder of 0, the code will return "Bzzst!". This code will run at most,
    7 times till we get a value that is divisible by 7.
    
    The if condition will be met whenever n or recurrsively n-1, is divisible by 7,
    making the worst case runtime of this code O(1)
  */ 
  public static String worstCase() {
    return "O(1)";
  }
  
  /*
    isTightBound is no longer a part of the question (it was here when i started
    the problem and got removed)
  */  
  public static Boolean isTightBound() {
    return true;
  }
  
  public static String mystery2(int n) {
    if (n % 7 == 0) {
      return "Bzzst!";
    }
    return mystery2(n-1);
  }
  
  public static void main(String[] args) { }
}