//HERE IS MY ATTEMPT AT canColor2
import java.util.*;
 
public class Coloring2 {
 
 public static void main(String[] args) {
   // Top left graph in first image
   Graph example1 = new Graph(
     new Integer[][] {
       {0, 1, 1, 0},
       {1, 0, 0, 1},
       {1, 0, 0, 1},
       {0, 1, 1, 0}
     }
   );
   // Middle graph in first image
   Graph example2 = new Graph(
     new Integer[][] {
       {0, 0, 0, 0},
       {0, 0, 0, 0},
       {0, 0, 0, 0},
       {0, 0, 0, 0}
     }
   );
   // Top right graph in first image
   Graph example3 = new Graph(
     new Integer[][] {
       {0, 1, 1, 0, 0},
       {1, 0, 0, 1, 0},
       {1, 0, 0, 1, 1},
       {0, 1, 1, 0, 0},
       {0, 0, 1, 0, 0}
     }
   );
 
   // Top left graph in second image
   Graph example4 = new Graph(
     new Integer[][] {
       {0, 1, 1, 0},
       {1, 0, 1, 1},
       {1, 1, 0, 1},
       {0, 1, 1, 0}
     }
   );
  // Top right graph in second image
   Graph example5 = new Graph(
     new Integer[][] {
       {0, 1, 1, 0, 0},
       {1, 0, 1, 1, 0},
       {1, 1, 0, 1, 1},
       {0, 1, 1, 0, 0},
       {0, 0, 1, 0, 0}
     }
   );
   // Bottom left graph in second image
   Graph example6 = new Graph(
     new Integer[][] {
       {0, 1, 1, 0},
       {1, 0, 1, 0},
       {1, 1, 0, 0},
       {0, 0, 0, 0}
     }
   );
   // Should all output true
   System.out.println(canColor(example1));
   System.out.println(canColor(example2));
   System.out.println(canColor(example3));
   // Should all output false
   System.out.println(canColor(example4));
   System.out.println(canColor(example5));
   System.out.println(canColor(example6));
 
  
   // Disconnected graph -- passes
   Graph example7 = new Graph(new Integer[][] {
     { 0, 1, 0, 0 },
     { 1, 0, 0, 0 },
     { 0, 0, 0, 1 },
     { 0, 0, 1, 0 }
   });
   System.out.println(canColor(example7));
 
   // Empty graph -- passes
   Graph example8 = new Graph(new Integer[][] {});
   System.out.println(canColor(example8));
 
   // Disconnected graph -- fails
   Graph example9 = new Graph(new Integer[][] {
     { 0, 1, 0, 0, 0 },
     { 1, 0, 0, 0, 0 },
     { 0, 0, 0, 1, 1 },
     { 0, 0, 1, 0, 1 },
     { 0, 0, 1, 1, 0 }
   });
   System.out.println(canColor(example9));
 
 }
 
 public static boolean canColor2(Graph g) {
   HashMap<Integer, String> visited = new HashMap<>();
   Stack<Integer> s =  new Stack<>();
   List<Integer> vertices = g.getVertices();
 
   if(g.getVertices().isEmpty()){
     return true;
   }
 
   s.push(vertices.get(0));
   visited.put(vertices.get(0), "red");
 
   return helper(g, visited, vertices.get(0), s);
 }
 
 public static boolean helper(Graph g, HashMap<Integer, String> visited, int a, Stack<Integer> s){
   if(s.isEmpty() && visited.size() == g.getVertices.size()){
     return true;
   }
   if(visited.containsKey(a)){
    
   }
   s.pop();
   for(int child: g.getNeighbors(a)){
     if(visited.containsKey(a)){
       return helper(g, visited, child, s);
     }
     else{
 
     }
   }
 
   return true;
 }
 
}
