import java.util.*;

public class Coloring {

  public static void main(String[] args) {
    // Top left graph in first image
    Graph example1 = new Graph(
      new Integer[][] {
        {0, 1, 1, 0},
        {1, 0, 0, 1},
        {1, 0, 0, 1},
        {0, 1, 1, 0}
      }
    );
    // Middle graph in first image
    Graph example2 = new Graph(
      new Integer[][] {
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0}
      }
    );
    // Top right graph in first image
    Graph example3 = new Graph(
      new Integer[][] {
        {0, 1, 1, 0, 0},
        {1, 0, 0, 1, 0},
        {1, 0, 0, 1, 1},
        {0, 1, 1, 0, 0},
        {0, 0, 1, 0, 0}
      }
    );

    // Top left graph in second image
    Graph example4 = new Graph(
      new Integer[][] {
        {0, 1, 1, 0},
        {1, 0, 1, 1},
        {1, 1, 0, 1},
        {0, 1, 1, 0}
      }
    );
   // Top right graph in second image
    Graph example5 = new Graph(
      new Integer[][] {
        {0, 1, 1, 0, 0},
        {1, 0, 1, 1, 0},
        {1, 1, 0, 1, 1},
        {0, 1, 1, 0, 0},
        {0, 0, 1, 0, 0}
      }
    );
    // Bottom left graph in second image
    Graph example6 = new Graph(
      new Integer[][] {
        {0, 1, 1, 0},
        {1, 0, 1, 0},
        {1, 1, 0, 0},
        {0, 0, 0, 0}
      }
    );
 
    // Should all output true
    System.out.println(canColor(example1));
    System.out.println(canColor(example2));
    System.out.println(canColor(example3));
    // Should all output false
    System.out.println(canColor(example4));
    System.out.println(canColor(example5));
    System.out.println(canColor(example6));

    
    // Disconnected graph -- passes
    Graph example7 = new Graph(new Integer[][] {
      { 0, 1, 0, 0 },
      { 1, 0, 0, 0 },
      { 0, 0, 0, 1 },
      { 0, 0, 1, 0 }
    });
    System.out.println(canColor(example7));

    // Empty graph -- passes
    Graph example8 = new Graph(new Integer[][] {});
    System.out.println(canColor(example8));

    // Disconnected graph -- fails
    Graph example9 = new Graph(new Integer[][] {
      { 0, 1, 0, 0, 0 },
      { 1, 0, 0, 0, 0 },
      { 0, 0, 0, 1, 1 },
      { 0, 0, 1, 0, 1 },
      { 0, 0, 1, 1, 0 }
    });
    System.out.println(canColor(example9));

  }

  public static boolean canColor(Graph g) {
    HashMap<Integer, String> visited = new HashMap<>();

    if(g.getVertices().isEmpty()){
      return true;
    }

    Queue<Integer> q = new LinkedList<>();
    List<Integer> vertices = g.getVertices();
    q.add(vertices.get(0));
    visited.put(vertices.get(0), "red");

    while(q.size() > 0){
      int curr = q.remove();
      vertices.remove(vertices.indexOf(curr));
      for(int neighbor: g.getNeighbors(curr)){
        if(visited.containsKey(neighbor)){
          if(visited.get(curr) == "red"){
            if(visited.get(neighbor) == "red"){
              return false;
            }
          }
          if(visited.get(curr) == "blue"){
            if(visited.get(neighbor) == "blue"){
              return false;
            }
          }
        }
        else{
            q.add(neighbor);
            if(visited.get(curr) == "red"){
              visited.put(neighbor, "blue");
            }
            else{
              visited.put(neighbor, "red");
            }
        }
      }

      //check for Disconnected
      if(q.isEmpty() && vertices.size() != 0){
           q.add(vertices.get(0));
           visited.put(vertices.get(0), "red");
       }
     }
    
    return true;
  }
}
