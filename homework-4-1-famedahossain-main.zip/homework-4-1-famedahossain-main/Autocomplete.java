import java.util.*;

public class Autocomplete {
  public static void main(String[] args) {
    TreeNode<Character> example = makeExample();
    
    System.out.println(candidates(example, "c")); // Outputs ["cat", "cow", "cut"]
    System.out.println(candidates(example, "ca")); // Outputs ["cat"]
    System.out.println(candidates(example, "an")); // Outputs ["and", "andrew"]
 
    // Outputs ["ace", "acne", "and", "andrew", "beam", "beef", "cat", "cow", "cut"]
    System.out.println(candidates(example, ""));
    System.out.println(candidates(example, "deer")); // Outputs []
    System.out.println(candidates(example, "bean")); // Outputs []
  }

  public static List<String> candidates(TreeNode<Character> root, String prefix) {
    TreeNode<Character> node = traverse(root, prefix, 0);
    List<String> results = new ArrayList<>();
    collect(node, prefix, results);
    return results;
  }

  //find node
  private static TreeNode<Character> traverse(TreeNode<Character> root, String prefix, int index) {
    if(prefix.length() == 0){
      return root;
    }
    if(root.getValue() == prefix.charAt(index)){
      if(index == prefix.length()-1){
        return root;
      }
      index++;
    }
    for(TreeNode<Character> child: root.getChildren()){
      if(child.getValue() == prefix.charAt(index)){
        return traverse(child, prefix, index);
      } 
    }
    return null;
  }

  //collect candidates
  private static void collect(TreeNode<Character> node, String wordSoFar, List<String> results) {
    if(node != null){
      if(node.getValue() == '$'){
      results.add(wordSoFar);
      }
    
    for(TreeNode<Character> child: node.getChildren()){
      if(child.getValue() == '$'){
        collect(child, wordSoFar, results);
      }
      else{
        collect(child, wordSoFar+child.getValue(), results);
      }
    }
    }
  }
  
  //works
  private static TreeNode<Character> makeExample() {
    return
      new TreeNode('*', Arrays.asList(
        new TreeNode('a', Arrays.asList(
          new TreeNode('c', Arrays.asList(
            new TreeNode('e', Arrays.asList(
              new TreeNode('$')
           )),
           new TreeNode('n', Arrays.asList(
              new TreeNode('e', Arrays.asList(
                new TreeNode('$')
              ))
           ))
         )),
          new TreeNode('n', Arrays.asList(
           new TreeNode('d', Arrays.asList(
             new TreeNode('$'),
                new TreeNode('r', Arrays.asList(
                  new TreeNode('e', Arrays.asList(
                    new TreeNode('w', Arrays.asList(
                      new TreeNode('$')
                  ))
                   ))
                 ))
               ))
             ))
            )),
        new TreeNode('b', Arrays.asList(
          new TreeNode('e', Arrays.asList(
           new TreeNode('a', Arrays.asList(
             new TreeNode('m', Arrays.asList(
               new TreeNode('$')
               ))
             )),
            new TreeNode('e', Arrays.asList(
              new TreeNode('f', Arrays.asList(
               new TreeNode('$')
             ))
           ))
         ))
        )),
        new TreeNode('c', Arrays.asList(
          new TreeNode('a', Arrays.asList(
            new TreeNode('t', Arrays.asList(
             new TreeNode('$')
           ))
         )),
          new TreeNode('o', Arrays.asList(
            new TreeNode('w', Arrays.asList(
             new TreeNode('$')
           ))
          )),
         new TreeNode('u', Arrays.asList(
            new TreeNode('t', Arrays.asList(
             new TreeNode('$')
           ))
         ))
       ))
      ));
  }

}

