class MaxHeap {
  
  public TArray arr;
  private int size;
  
  public MaxHeap(TArray input) {
    this.arr = input;
    this.size = 0;
  }
  
  private int parent(int i) {
    return (i-1) / 2;
  }
  
  private int left(int i) {
    return i * 2 + 1;
  }
  
  private int right(int i) {
    return i * 2 + 2;
  }
  
  public void add(int element) {
    arr.set(size, element);
  
    int sizeHolder = size;
    size++;
    while (arr.get(sizeHolder) > arr.get(parent(sizeHolder))) { 
      arr.swap(sizeHolder, parent(sizeHolder)); 
      sizeHolder = parent(sizeHolder);
    } 
  }
  
  public int extractMax() {
    int max = peek();
    arr.set(0, arr.get(size-1));
    arr.set(size-1, 0);
    
    int place = 0;
    while(arr.get(place) < arr.get(left(place)) || arr.get(place) < arr.get(right(place))){
      if(arr.get(left(place)) > arr.get(right(place))){
        arr.swap(place, left(place));
        place = left(place);
      }
      else{
        arr.swap(place, right(place));
        place = right(place);
      }
    }
    
    size--;
    return max;
    
  }
  
  public int peek() {
    return arr.get(0);
  }
  
  public int size() {
    return size;
  }

  public String toString() {
    return arr.toString();
  }

}
