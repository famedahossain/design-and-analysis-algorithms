class Main {

  public static int partition(TArray arr, int left, int right) {
    int pivot = arr.get(right);
    int fringe = left;
    int i = left;
    
    for(int j=left; j<right; j++){
      if(arr.get(j) <= pivot){
        arr.swap(j, fringe);
        fringe++;
      }
    }
    arr.swap(fringe, right);
    
    return fringe;
  }
  
  public static void quickSort(TArray arr) {
    quickSort(arr, 0, arr.size()-1);
  }
  
  private static void quickSort(TArray arr, int left, int right) {
    if (left < right) {
      int pivotIndex = partition(arr, left, right);
      quickSort(arr, left, pivotIndex-1);
      quickSort(arr, pivotIndex+1, right);
    }
  }

  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * We have examples to help you get started.
  * 
  * {5, 4, 1, 11, 9, 6, 2, 3} should output 2
  * 
  * {10, 80, 30, 90, 40, 50, 70} should output 4
  * 
  * {1, 2, 3, 4, 5, 6, 7} should output 6
  */
  public static void main(String[] args) {
    TArray example1 = new WrappedArray(new int[] {1, 9, 4, 2, 3});
    int pivot = partition(example1, 0, 4);
    System.out.println(example1); // Should output [1, 2, 3 , 9, 4]
    System.out.println(pivot);    // Should output 2
    
    TArray example2 = new WrappedArray(new int[] {1, 8, 3, 4, 0, 7, 9, 6, 2, 5});
    pivot = partition(example2, 4, 9);
    System.out.println(example2); // Should output [1, 8, 3, 4, 0, 2, 5, 6, 7, 9]
    System.out.println(pivot);    // Should output 6
    
     TArray example3 = new WrappedArray(new int[] {1, 8, 3, 4, 0, 7, 9, 6, 2, 5});
     quickSort(example3);
     System.out.println(example3); // Should output [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
  }
}