class Main {
  /*
    The worst case runtime is O(log(n)), where n is the inputed value. In this
    case we want the code to have to do as many recursions as it can. 
    It will still take the value, n, and divide it by 10 recurssively, so even 
    as n grows bigger, it will still follow the same process and divide 
    n by 10 until the if condition isn't true. Therefore even in the worst case,
    where n gets bigger and bigger, the runtime is still log(n)
    
    (Even though it's log base 10, the base doesn't matter when we do big O)
  */ 
  public static String worstCase() {
    return "O(log(n))";
  }
  
  public static void mystery1(int n) {
    System.out.println(n);
    if (n >= 10) {
      mystery1(n/10);
      System.out.println(n);
    }
  }
  
  public static void main(String[] args) {
    mystery1(103472);
  }
}