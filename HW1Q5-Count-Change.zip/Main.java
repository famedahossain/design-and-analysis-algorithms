class Main {
  public static int countChange(int[] denominations, int target) {
		 int value;
		 value = helper(denominations, target, 0);
		 return value;
	}
	 
	 public static int helper(int[] denominations, int target, int startPosition) {
		 if (target == 0) {
		    return 1;
		 }
		 if (target < 0) {
		    return 0;
		 }
		 int totalSum = 0;
     for(int i=startPosition; i<denominations.length; i++){
        totalSum += helper(denominations, target-denominations[i], i);
     }
     return totalSum;
		}
  
  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * We have provided an example to help you get started.
  * 
  * what should my base cases be? base cases probably should deal with the target
  * make sure you don't get repetitions of the same way to add up
  * 
  * int[] denominations = {1, 5}
  * countChange(denominations, 6)
  * should output 2
  * 1+1+1+1+1+1
  * 5+1
  * 
  * int[] denominations1 = {7, 3, 10}
  * countChange(denominations1, 20)
  * should output 3
  * 10+10
  * 7+7+3+3
  * 10+7+3
  * 
  */
  public static void main(String[] args) {
    int[] denominations = {1, 5, 10};
    System.out.println(countChange(denominations, 14));
  }
}