import java.util.*;

class Main {
  
  public static ArrayList<Integer> treePathSums(TreeNode root) {
    ArrayList<Integer> values = new ArrayList<Integer>();
    if (root == null){
      return values;
    }
    if (root.left == null && root.right == null) {
      values.add(root.value);
	    return values;
    }
	
	  helper(root.left, root.value, values);
    values.addAll(helper(root.right, root.value, values));
	 
	  return values;
}

public static ArrayList<Integer> helper(TreeNode root, int sum, ArrayList<Integer> currentSumList){ 
	ArrayList<Integer> addItMan = new ArrayList<Integer>();
  	if(root == null) {
  		return currentSumList;
  	}
    else{
      if(root.left == null && root.right == null){
   		  currentSumList.add(sum+root.value);
   		  return currentSumList;
   	  }
    }
    
    helper(root.left, sum+root.value, addItMan);
    helper(root.right, sum+root.value, addItMan);
    return addItMan;

}

  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * We have provided an example to help you get started.
  * 
  * start off by determing what happens when the root is null, than what if the
  * root is the only value in the tree?
  * 
  * use a helper method to do a "running sum", and recursively call the method on
  * itself for the left and right of the root node. this method will return arraylists with the sums of each root-to-leaf path.
  * 
  * make sure to combine the arraylists into one with all the sums by using
  * .addAll and then return the arraylist
  * 
  * what my helper method should look like:
  * check if root is null
  * check if root's children are null: if yes, add root.value to the running sum. and return. (reached last leaf)
  * recurse if children exist on root.left and root.right
  */
  public static void main(String[] args) {
    TreeNode example = new TreeNode(5, new TreeNode(1), new TreeNode(2, new TreeNode(2), new TreeNode(6)));

    // Should output [6, 9, 13]
    System.out.println(treePathSums(example).toString());
  }
  
  /** Confidence:
  * Once you complete the exercise above, fill this method out
  * based on how confident you are in your answer above. Return...
  *   1 if "I’m guessing / I don’t know"
  *   2 if "I’m somewhat confident that my answer is correct"
  *   3 if "I’m fairly confident that my answer is correct"
  *   4 if "I’m highly confident that my answer is correct"
  *   5 if "I’m absolutely confident that my answer is correct"
  */
  public static int confidence() {
    return 2;
  }
}