import java.util.*;

class Main {
  /*
    Write your pseudocode here.
    
    algorithm twoSumFast
      Input: list of integers Lst of size N and integer target
      Output: list with index of (el1) and index of (el2) such that index of (el1)+index of (el2)=target; -1, -1 otherwise
      
      seen = empty hashset of integers
      for element el1 in Lst
        otherAddend = target - el1
        if seen.contains(otherAddend)
          for element el2 in Lst
            if el2 = otherAddend
              return index of (el1), index of (el2)
        else
          seen.add(el1)
    
      return -1, -1

  */
  
  public static int[] twoSumFast(int[] arr, int target) {
    HashSet<Integer> seen = new HashSet<>();
    for (int j = 0; j < arr.length; j++) {
      int otherAddend = target - arr[j];
      if (seen.contains(otherAddend)) {
        for (int i = 0; i < arr.length; i++) {
          if (arr[i] == otherAddend)  {
            return new int[] {i, j};
          }
        }
      } else {
        seen.add(arr[j]);
      }
    }
    return new int[] {-1, -1};
  }
  
  public static void main(String[] args) {
    int[] example = {0, 4, 10, 19, 9, 2, 7, 3, 8, 10};
    System.out.println(Arrays.toString(twoSumFast(example, 22)));
  }
}