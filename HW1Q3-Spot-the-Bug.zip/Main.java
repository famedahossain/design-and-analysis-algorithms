class Main {
  
  public static int remainder(int x, int y) {
    assert x >= 0 : "x is non-negative";
    assert y > 0  : "y is positive";
    if (x <= y) {
      return x;
    }
    return remainder(x - y, y);
  }
  
  public static int binarySearch(int[] arr, int x) {
    return binarySearch(arr, x, 0, arr.length-1); 
  }
  
  private static int binarySearch(int[] arr, int x, int a, int b) {
    if (a >= b) {
      return -1;
    }
    int midpoint = (b + a) / 2;
    if (arr[midpoint] == x) {
      return midpoint;
    } else if (arr[midpoint] < x) {
      return binarySearch(arr, x, a+1, midpoint);
    } else {
      return binarySearch(arr, x, midpoint, b-1);
    }
  }
  
  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * 
  * the bug in remainder:
  * the issue is present in the if condition
  * if (x <= y) {
      return x;
    }
    for example the call, remainder(2,2) will cause an output of 2, even though
    2/2 gets a remainder of 0. same will apply for other examples where x equals y.
    
    by looking at these examples you can see that the bug lies in the if 
    condition and the way it checks when the two inputed values are equivalent and what
    it is returning
  * 
  * 
  * the bugs in binarySearch: 
  * the first condition is present in the first if condition
  * if (a >= b) {
      return -1;
    }
    because the condition allows for a (the lowerbound) to be equal to b (the upperbound)
    we will return -1 when an instance of that happens, even if we still have another element we can find
    for example if you did the array 1,2,3,4,5 and looked for 2, the if condition would prevent us
    from being able to get to 2, since when a=b, it would return -1.
    
    the next two bugs are present in the else conditions
  * else if (arr[midpoint] < x) {
      return binarySearch(arr, x, a+1, midpoint);
    } else {
      return binarySearch(arr, x, midpoint, b-1);
    }
    
    the return statements are incorrect. 
    
    when arr[midpoint] < x, 
    the correct return should be return binarySearch(arr, x, midpoint+1, b) because
    we need to check the values above the midpoint to the end of the array to find our target.
    we should not be checking from a+1 to the midpoint because our value will not be there.
    the incorrect return checks the lower array when we should be checking the upper array.
    
    for the else statement
    the correct return should be return binarySearch(arr, x, a, midpoint-1) because
    we need to check the values below the midpoint to the beginning of the array to find our target.
    we should not be checking from midpoint to the b-1 because our value will not be there. 
    the incorrect return checks the upper array when we should be checking the lower array.
    
    if we used an example such as {1, 9, 18, 94, 113} and looked for 94, the code would return a -1,
    because based on the incorrect else statements, it would not find it.
    
    valid example calls that would lead to incorrect results:
    remainder(2,2)
    int[] example2 = {1, 9, 18, 94, 113}
    binarySearch(example2, 94)
  */
  
  public static void main(String[] args) {
    int[] example = {1, 2, 8, 16, 32, 128};
    System.out.println(binarySearch(example, 0));
  }
  
}