class Main {
  
  public static int findMissing(int[] arr) {
    int sum = 0;
    int N = arr.length;
    for(int i=0; i<arr.length; i++) {
      sum = sum + arr[i];
    }
    
    return (N*(N+1))/2 - sum;
    
  }
  
  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * 
  * use a for loop to get the total sum of the array 
  * then use the give return statement to return the missing number
  * 
  */
  public static void main(String[] args) {
  }

}