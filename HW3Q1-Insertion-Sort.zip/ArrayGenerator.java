import java.util.*;

// YOU SHOULD NOT MODIFY THIS FILE IN ANY WAY
// YOU SHOULD NOT MODIFY THIS FILE IN ANY WAY
// YOU SHOULD NOT MODIFY THIS FILE IN ANY WAY
// YOU SHOULD NOT MODIFY THIS FILE IN ANY WAY

class ArrayGenerator {
  
  public static int[] generate(String seedAsString) {
    Long seed = Long.parseLong(seedAsString);
    if (seed == 0) {
      return new int[] {9, 4, 5, 1, 5, 2};
    }
    int [] result = new int[6];
    Random generator = new Random(seed);
    for (int i = 0; i < result.length; i++) {
      result[i] = generator.nextInt(100);
    }
   return result; 
  }
  
}