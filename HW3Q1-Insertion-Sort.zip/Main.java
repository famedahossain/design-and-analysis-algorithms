import java.util.*;

class Main {
  public static String seed() {
    return "002402840"; // REPLACE WITH PANTHER ID
  }
  
  public static void main(String[] args) {
    System.out.println("Your array: ".concat(Arrays.toString(ArrayGenerator.generate(seed()))));
  }
  
  public static int[][] stepsForInsertionSort() {
    return new int[][] {
      {50, 44, 63, 70, 89, 11}, 
      
      {50, 50, 63, 70, 89, 11}, //i=1
      {44, 50, 63, 70, 89, 11}, 
      
      {44, 50, 63, 70, 89, 11}, //i=2
      
      {44, 50, 63, 70, 89, 11}, //i=3
      
      {44, 50, 63, 70, 89, 11}, //i=4
      
      {44, 50, 63, 70, 89, 89}, //i=5
      {44, 50, 63, 70, 70, 89},
      {44, 50, 63, 63, 70, 89},
      {44, 50, 50, 63, 70, 89},
      {44, 44, 50, 63, 70, 89},
      {11, 44, 50, 63, 70, 89}
    };
  }

}