import java.util.*;

class Main {
  
  public static void reverse(int[] arr) {
    if (arr == null || arr.length < 2){
      return;
    }
    for(int i=0; i<arr.length/2; i++){
      int original = arr[i];
      arr[i]= arr[arr.length-1-i];
      arr[arr.length-1-i] = original;
    }
    return;
  }
  
  /** Testing and Effort:
  * Feel free to experiment and write examples here to test your code.
  * Leave your work here to earn extra credit under the "effort" pillar.
  * We have provided an example to help you get started.
  * 
  * rationale: go through the array and swap the values at the first 
  * and last indexes. you only need to go up to the midpoint of the array.
  * 
  * below is the logic needed to go through the array and swap the first and last values
  * and then going up one from the first index and minus one from the last index up to the midpoint of
  * the array. 
  * for(int i=0; i<array.length/2; i++){
      int valueofelement = arr[i];
      arr[i]= arr[arr.length-1-i];
      arr[arr.length-1-i] = valueofelement;
  * 
  */
  public static void main(String[] args) {
    int[] example1 = {1,2, 3, 4, 5};
    reverse(example1);

    // Should output [5, 4, 3, 2, 1]
    System.out.println(Arrays.toString(example1));
  }
  
  /** Confidence:
  * Once you complete the exercise above, fill this method out
  * based on how confident you are in your answer above. Return...
  *   1 if "I’m guessing / I don’t know"
  *   2 if "I’m somewhat confident that my answer is correct"
  *   3 if "I’m fairly confident that my answer is correct"
  *   4 if "I’m highly confident that my answer is correct"
  *   5 if "I’m absolutely confident that my answer is correct"
  */
  public static int confidence() {
    return 5;
  }
}