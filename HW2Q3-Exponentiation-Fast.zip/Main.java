class Main {
  /*
    The best case runtime would be O(log(n)), where n is equal to the power.
    In the best case our power would be even, thus allowing for the 
    number of recursive steps to be divided by 2 each time.

  */ 
  public static String bestCase() {
    return "O(log(n))";
  }

  /*
    The worst case runtime would be O(n), where n is equal to the power.
    In the worst case, when the power is odd we have to go into the else statement
    and subtract two from n each time which will still be odd and so the number
    of times we're recursing will be n/2 which is still just O(n).
  */ 
  public static String worstCase() {
    return "O(n)";
  }
  
  /*
    The average case runtime would be O(n) where n is equal to the power.
    In this case, sometimes n, or the power, will be even and sometimes it will be odd
    which taken from the best and worst case would be n + log(n) but knowing how big O works,
    we know that the average case would just be O(n).
  */  
  public static String averageCase() {
    return "O(n)";
  }
  
  public static int pow(int a, int power) {
    if (power == 0) {
      return 1;
    } else if (power == 1) {
      return a;
    } else if (power % 2 == 0) {
      int temp = pow(a, power / 2);
      return temp * temp;
    } else {
      return a * a * pow(a, power-2); 
    }
  }
  
  /*To make this code better we would change this return here (return a * a * pow(a, power-2)) to 
    return a*pow(a, power-1) which will make the worst case runtime O(log(n)) because in the worst case, 
    if the power is odd, the code will subtract one from the power, making it even and thus
    allowing is to recurse using the else if condition, effectively cutting the runtime
    down. This would make the worst case runtime log(n) which is better than the runtime it currently
    has.
  */
  
  public static void main(String[] args) { }
}